jQuery(document).ready(function(){
	
	
	jQuery('#nav-button').click(function() {
			jQuery('#options li').toggle(0);
	});
	
});	
	

import React,{ PropTypes,Component} from 'react';
import {
    requireNativeComponent,
    View,
} from 'react-native';


var VideoView = {
    name:'VideoView',
    propTypes:{
        style: View.propTypes.style,
        source:React.PropTypes.shape({
            url:React.PropTypes.string,
            headers:React.PropTypes.object,
        }),
        ...View.propTypes,
    }
};
var RCTVideoView = requireNativeComponent('VideoView',VideoView);
module.exports = RCTVideoView;

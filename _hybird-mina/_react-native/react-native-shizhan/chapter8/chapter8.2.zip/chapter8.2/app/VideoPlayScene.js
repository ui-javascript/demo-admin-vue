import React, {Component} from 'react';
import {
    View,
    WebView,
    Text,
    NativeModules,
    TouchableOpacity
} from 'react-native';
var Orientation = NativeModules.Orientation;
import VideoView from './component/VideoView';
import BaseTitleBarScene from './component/BaseTitleBarScene';

export default class VideoPlayScene extends BaseTitleBarScene {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        Orientation.setOrientation(Orientation.LANDSCAPE);
    }

    componentWillUnmount() {
        Orientation.setOrientation(Orientation.PORTRAIT);
    }


    renderContent() {
        var html = '';
        var url = this.props.data.url;
            console.log('url=' + url);
            return (
                <View style={{flex: 1, backgroundColor: 'black',}}>
                    <WebView
                        style={{flex: 1, backgroundColor: 'black',}}
                        source={{uri: url}}
                        javaScriptEnabled={true}//android
                        domStorageEnabled={true}//android
                        startInLoadingState={true}
                        scalesPageToFit={true}
                        automaticallyAdjustContentInsets={true}//
                        allowsInlineMediaPlayback={true}//ios
                        scrollEnabled={false}//ios
                        renderError={()=> {
                            console.log('渲染失败');
                        }}
                        onError={(e)=> {
                            console.log('网页加载失败 e = ' + e.toString());
                        }}
                        onLoad={()=> {
                            console.log('网页成功加载完成');
                        }}
                        onLoadEnd={()=> {
                            console.log('网页加载结束');
                        }}
                        onLoadStart={()=> {
                            console.log('网页开始加载');
                        }}
                        onShouldStartLoadWithRequest={(request)=> {
                            return true;
                        }}
                    />
                </View>
            );
        //}
    }
}
import React, {Component} from 'react';
import {
    View,
    StyleSheet,
    Text,
    TouchableOpacity
} from 'react-native';
import VideoView from './component/VideoView';

export default class VideoPlayView extends Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <View style={styles.videoContainer}>

                <Text style={styles.text}>康熙王朝</Text>
                <VideoView
                    style={styles.video}
                    source={
                           {
                            url: 'http://ohe65w0xx.bkt.clouddn.com/test3.mp4',
                            headers: {
                                'refer': 'myRefer'
                            }
                        }
                    }
                />
            </View>
        );
    }
}


const styles = StyleSheet.create({
    videoContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    text: {
        fontSize: 20,
        justifyContent: 'center',
    },
    video: {
        marginTop:10,
        height: 250,
        width: 380
    },

});

import React, { PropTypes } from 'react';
import {
    requireNativeComponent,
    View,
    UIManager,
    findNodeHandle,
    ReactNative,
    Platform } from 'react-native';


 var LottieView = {
 name: 'LottieView',
 defaultProps: {
 progress: 0,
 loop: true,
 },
 propTypes: {
 sourceName :React.PropTypes.string,
 progress: React.PropTypes.number,
 loop: React.PropTypes.bool,
 ...View.propTypes // 包含默认的View的属性
 },
 };

 module.exports = requireNativeComponent('LottieAnimationView', LottieView);


// const Lottie = requireNativeComponent('LottieAnimationView', LottieView);
//
// class LottieView extends React.Component {
//
//     constructor(props) {
//         super(props);
//     }
//
//     play() {
//         this.runCommand('play');
//     }
//
//     reset() {
//         this.runCommand('reset');
//     }
//
//     runCommand(name, args = []) {
//         return Platform.select({
//             android: () => UIManager.dispatchViewManagerCommand(
//                 this.getHandle(),
//                 UIManager.LottieAnimationView.Commands[name],
//                 args
//             ),
//             ios: () => LottieViewManager[name](this.getHandle(), ...args),
//         })();
//     }
//     getHandle() {
//         return findNodeHandle(this.refs.lottieView);
//     }
//
//     render() {
//         return <Lottie ref="lottieView" {...this.props} loop={true} />;
//     }
// }
//
// module.exports = LottieView;
/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, {Component} from 'react';
import {
    AppRegistry,
    StyleSheet,
} from 'react-native';

import VideoPlayView from './app/VideoPlayView'

export default class lottie extends Component {

    render() {
        return (
            <VideoPlayView/>

        );
    }
}

const styles = StyleSheet.create({
    lottieContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    lottie: {
        width: 400,
        height:400

    },

});

AppRegistry.registerComponent('lottie', () => lottie);
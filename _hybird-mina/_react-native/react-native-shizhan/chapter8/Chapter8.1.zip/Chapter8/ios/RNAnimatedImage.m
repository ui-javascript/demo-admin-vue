//
//  RNAnimatedImage.m
//  Chapter8
//
//  Created by xiangzhihong on 2017/7/1.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import "RNAnimatedImage.h"
#import "FLAnimatedImageView.h"
#import "RCTBridgeModule.h"
#import "RCTEventDispatcher.h"
#import "UIView+React.h"
#import "RCTLog.h"
#import "RNAnimatedImage.h"


@implementation RNAnimatedImage:UIView{
  RCTEventDispatcher *eventDispatcher;
  FLAnimatedImageView *image;
  
  
  
}




@end

//
//  RNAnimatedImage.h
//  Chapter8
//
//  Created by xiangzhihong on 2017/7/1.
//  Copyright © 2017年 Facebook. All rights reserved.
//

#import "RCTView.h"
#import "RCTEventDispatcher.h"
#import "FLAnimatedImageView.h"

@class RCTEventDispatcher;//React Native事件调度器
@interface RNAnimatedImage : UIView
@property  (nonatomic,assign)NSString *src;
@property  (nonatomic,assign)NSNumber *content;

 -(instancetype)initWithEventDispatcher:(RCTEventDispatcher *)eventDispatcher NS_DESIGNATED_INITIALIZER;

@end

//
//  RNAnimatedImageManager.m
//  Chapter8
//
//  Created by xiangzhihong on 2017/7/1.
//  Copyright © 2017年 Facebook. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "RNAnimatedImageManager.h"
#import "RNAnimatedImage.h"
#import "RCTBridge.h"

@implementation RNAnimatedImageManager

// 标记宏（必要）用来申明这个类需要被导出
RCT_EXPORT_MODULE()

@synthesize bridge=_bridge;
- (UIView *)view
{
  return [[RNAnimatedImage alloc] initwithEventDispatcher:self.bridge.eventDispatcher]
}
methodQueue{
  
}

@end
